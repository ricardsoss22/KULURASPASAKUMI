<!DOCTYPE html>
<html>
<head>
    <title>Pasākumi</title>
</head>
<body>
    <h1>Laipni lūgti Pasākumu lapā!</h1>
    <p>Lūdzu, izvēlieties savu lomu:</p>
    <a href="pasakumi.user.php"><button>User</button></a>
    <a href="kolektivi.php"><button>CKC kolektīvi</button></a>
    <a href="pasakumi.admin.php"><button>admin pasakumi</button></a>
    <a href="kolektivi.admin.php"><button>admin kolektivi</button></a>
</body>
</html>
